# Nexus CRM — MERN + Next.js

A full-featured Customer Relationship Management system built with MongoDB, Express.js, React (Next.js), and Node.js.

---

## 📁 Project Structure

```
nexus-crm/
├── backend/          # Express.js + MongoDB API
│   ├── models/       # Mongoose schemas (User, Customer, Invoice)
│   ├── routes/       # API routes (auth, customers, invoices, dashboard)
│   ├── middleware/   # JWT auth middleware
│   ├── server.js     # Express entry point
│   └── seed.js       # Database seeder (15+ customers)
└── frontend/         # Next.js app
    ├── pages/        # All pages (login, register, dashboard, customers, invoices, settings)
    ├── components/   # Layout, Chatbot, CustomerForm, withAuth HOC
    ├── context/      # AuthContext (JWT management)
    ├── lib/          # Axios API client
    └── styles/       # Global CSS
```

---

## ✅ Features Implemented

| Feature | Status |
|---|---|
| JWT Authentication (register/login/logout) | ✅ |
| Protected routes | ✅ |
| Customer CRUD (add, view, edit, delete) | ✅ |
| 15+ seeded customer records | ✅ |
| Search customers by name | ✅ |
| Filter by status (Lead/Active/Inactive) | ✅ |
| Invoice generation with PDF download | ✅ |
| Toast notifications (success/error/confirm) | ✅ |
| Rule-based chatbot assistant | ✅ |
| Dashboard with stats | ✅ |
| Responsive UI | ✅ |
| Next.js SSR/CSR | ✅ |

---

## 🚀 Setup Instructions

### Prerequisites
- Node.js 18+
- MongoDB (local or MongoDB Atlas)
- npm

---

### 1. Clone / Extract the project

```bash
cd nexus-crm
```

### 2. Setup Backend

```bash
cd backend
npm install
```

Create a `.env` file (copy from `.env.example`):
```bash
cp .env.example .env
```

Edit `.env` with your MongoDB URI:
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/nexus-crm
JWT_SECRET=nexus_crm_secret_key_2024
JWT_EXPIRE=7d
```

**Seed the database** (creates admin user + 16 customers):
```bash
npm run seed
```

**Start the backend server:**
```bash
npm run dev     # development (with nodemon)
# or
npm start       # production
```

Backend runs on: **http://localhost:5000**

---

### 3. Setup Frontend

```bash
cd ../frontend
npm install
```

Create `.env.local`:
```bash
cp .env.local.example .env.local
```

Content of `.env.local`:
```
NEXT_PUBLIC_API_URL=http://localhost:5000/api
```

**Start the frontend:**
```bash
npm run dev
```

Frontend runs on: **http://localhost:3000**

---

## 🔑 Demo Login

After seeding, use these credentials:

| Field | Value |
|---|---|
| Email | admin@nexuscrm.com |
| Password | admin123 |

---

## 🌐 API Endpoints

### Auth
- `POST /api/auth/register` — Register new user
- `POST /api/auth/login` — Login
- `GET /api/auth/me` — Get current user (protected)

### Customers
- `GET /api/customers` — List all (supports `?search=&status=&page=&limit=`)
- `GET /api/customers/:id` — Get one
- `POST /api/customers` — Create
- `PUT /api/customers/:id` — Update
- `DELETE /api/customers/:id` — Delete

### Invoices
- `GET /api/invoices` — List all
- `POST /api/invoices` — Create
- `DELETE /api/invoices/:id` — Delete
- `GET /api/invoices/:id/pdf` — Download PDF

### Dashboard
- `GET /api/dashboard/stats` — Get summary stats

---

## 🤖 Chatbot Commands

The built-in rule-based assistant (click 💬 button) responds to:

| Command | Action |
|---|---|
| `hello` / `hi` | Greeting |
| `help` | Show all commands |
| `show customers` | Navigate to customers |
| `add customer` | Open add customer form |
| `create invoice` | Open invoice page |
| `dashboard` | Navigate to dashboard |
| `customer count` | Show customer stats |
| `show invoices` | Navigate to invoices |

---

## 📦 Tech Stack

**Backend:** Node.js, Express.js, MongoDB, Mongoose, JWT, bcryptjs, PDFKit

**Frontend:** Next.js 13, React 18, Axios, react-hot-toast

---

## 🗒️ Notes

- All dashboard routes are JWT-protected (401 redirects to login)
- Passwords are hashed with bcryptjs (12 salt rounds)
- Invoices auto-generate a unique invoice number (INV-YYYY-NNNN)
- PDF generation is server-side using PDFKit
- Tax is calculated at 10% automatically
