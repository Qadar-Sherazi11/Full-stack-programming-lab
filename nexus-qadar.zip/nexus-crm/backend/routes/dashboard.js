const express = require('express');
const router = express.Router();
const Customer = require('../models/Customer');
const Invoice = require('../models/Invoice');
const { protect } = require('../middleware/auth');

router.use(protect);

// @route GET /api/dashboard/stats
router.get('/stats', async (req, res) => {
  try {
    const totalCustomers = await Customer.countDocuments();
    const activeCustomers = await Customer.countDocuments({ status: 'Active' });
    const leads = await Customer.countDocuments({ status: 'Lead' });
    const invoices = await Invoice.find({ status: 'Paid' });
    const revenue = invoices.reduce((sum, inv) => sum + inv.total, 0);

    const recentCustomers = await Customer.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .select('name email status company createdAt');

    res.json({
      totalCustomers,
      activeCustomers,
      leads,
      revenue: revenue.toFixed(2),
      recentCustomers,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
