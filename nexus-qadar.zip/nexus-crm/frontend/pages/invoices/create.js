import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Layout from '../../components/layout/Layout';
import withAuth from '../../components/ui/withAuth';
import api from '../../lib/api';
import toast from 'react-hot-toast';
import Link from 'next/link';

const emptyService = () => ({ description: 'Consulting Services', hours: 1, rate: 150 });

function CreateInvoice() {
  const router = useRouter();
  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [services, setServices] = useState([emptyService()]);
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setLoading(true);
    api.get('/customers', { params: { limit: 100 } })
      .then(({ data }) => setCustomers(data.customers))
      .catch(() => toast.error('Failed to load customers'))
      .finally(() => setLoading(false));
  }, []);

  const addService = () => setServices([...services, emptyService()]);
  const removeService = (i) => setServices(services.filter((_, idx) => idx !== i));
  const updateService = (i, field, value) => {
    const updated = [...services];
    updated[i] = { ...updated[i], [field]: field === 'description' ? value : Number(value) };
    setServices(updated);
  };

  const subtotal = services.reduce((sum, s) => sum + s.hours * s.rate, 0);
  const tax = subtotal * 0.1;
  const total = subtotal + tax;
  const customerObj = customers.find((c) => c._id === selectedCustomer);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedCustomer) return toast.error('Please select a customer');
    if (services.some((s) => !s.description)) return toast.error('All service descriptions are required');

    setSaving(true);
    try {
      await api.post('/invoices', { customer: selectedCustomer, services, dueDate, notes });
      toast.success('Invoice created successfully!');
      router.push('/invoices');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create invoice');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Layout>
      <div className="page-header">
        <div className="page-title">
          <div style={{ fontSize: 13, color: '#666', marginBottom: 4 }}>
            <Link href="/invoices">Invoices</Link> › Create New
          </div>
          <h1>Invoice Generation</h1>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 20, alignItems: 'start' }}>
        {/* Left: Form */}
        <div>
          <form onSubmit={handleSubmit}>
            {/* Customer Selection */}
            <div className="card" style={{ marginBottom: 16 }}>
              <h3 style={{ fontWeight: 700, marginBottom: 16 }}>👤 Customer Selection</h3>
              <div className="form-row">
                <div className="form-group">
                  <label>Select Customer *</label>
                  {loading ? <p>Loading customers...</p> : (
                    <select value={selectedCustomer} onChange={(e) => setSelectedCustomer(e.target.value)}>
                      <option value="">-- Select a customer --</option>
                      {customers.map((c) => (
                        <option key={c._id} value={c._id}>{c.name} {c.company ? `(${c.company})` : ''}</option>
                      ))}
                    </select>
                  )}
                </div>
                <div className="form-group">
                  <label>Due Date</label>
                  <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
                </div>
              </div>
            </div>

            {/* Service Rows */}
            <div className="card" style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <h3 style={{ fontWeight: 700 }}>🛠️ Service Rows</h3>
                <button type="button" className="btn-secondary btn-sm" onClick={addService}>+ Add Row</button>
              </div>

              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr>
                    <th style={{ textAlign: 'left', padding: '8px 0', fontSize: 12, color: '#666' }}>Description</th>
                    <th style={{ textAlign: 'left', padding: '8px 8px', fontSize: 12, color: '#666', width: 80 }}>Hours</th>
                    <th style={{ textAlign: 'left', padding: '8px 8px', fontSize: 12, color: '#666', width: 100 }}>Rate ($)</th>
                    <th style={{ textAlign: 'left', padding: '8px 8px', fontSize: 12, color: '#666', width: 100 }}>Total</th>
                    <th style={{ width: 40 }}></th>
                  </tr>
                </thead>
                <tbody>
                  {services.map((s, i) => (
                    <tr key={i}>
                      <td style={{ paddingRight: 8, paddingBottom: 8 }}>
                        <input
                          value={s.description}
                          onChange={(e) => updateService(i, 'description', e.target.value)}
                          placeholder="Service description"
                        />
                      </td>
                      <td style={{ padding: '0 8px 8px' }}>
                        <input type="number" min="0" step="0.5" value={s.hours} onChange={(e) => updateService(i, 'hours', e.target.value)} />
                      </td>
                      <td style={{ padding: '0 8px 8px' }}>
                        <input type="number" min="0" value={s.rate} onChange={(e) => updateService(i, 'rate', e.target.value)} />
                      </td>
                      <td style={{ padding: '0 8px 8px', fontWeight: 600 }}>
                        ${(s.hours * s.rate).toFixed(2)}
                      </td>
                      <td style={{ paddingBottom: 8 }}>
                        {services.length > 1 && (
                          <button type="button" onClick={() => removeService(i)} style={{ background: 'none', color: 'var(--danger)', fontSize: 16, padding: '4px 8px' }}>✕</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Notes */}
            <div className="card" style={{ marginBottom: 16 }}>
              <div className="form-group" style={{ marginBottom: 0 }}>
                <label>Notes (optional)</label>
                <textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Additional notes..." rows={2} />
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button type="button" className="btn-secondary" onClick={() => router.push('/invoices')}>Cancel</button>
              <button type="submit" className="btn-primary" disabled={saving}>
                {saving ? 'Saving...' : '💾 Save Invoice'}
              </button>
            </div>
          </form>
        </div>

        {/* Right: Preview */}
        <div className="card invoice-preview" style={{ position: 'sticky', top: 24 }}>
          <div style={{ borderBottom: '2px solid var(--primary)', paddingBottom: 12, marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 18, color: 'var(--primary)' }}>NEXUS</div>
                <div style={{ fontSize: 11, color: '#666' }}>ENTERPRISE INVOICE</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 11, color: '#666' }}>INVOICE #</div>
                <div style={{ fontWeight: 700 }}>AUTO-GENERATED</div>
                <div style={{ fontSize: 11, color: '#666' }}>{new Date().toLocaleDateString()}</div>
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16, fontSize: 12 }}>
            <div>
              <div style={{ fontWeight: 600, marginBottom: 4, color: '#666', textTransform: 'uppercase', fontSize: 10 }}>From</div>
              <div style={{ fontWeight: 600 }}>Nexus CRM Corp</div>
              <div style={{ color: '#666' }}>128 Enterprise Way<br />Silicon Valley, CA 94043</div>
            </div>
            <div>
              <div style={{ fontWeight: 600, marginBottom: 4, color: '#666', textTransform: 'uppercase', fontSize: 10 }}>Bill To</div>
              {customerObj ? (
                <>
                  <div style={{ fontWeight: 600 }}>{customerObj.name}</div>
                  <div style={{ color: '#666' }}>{customerObj.email}</div>
                  {customerObj.company && <div style={{ color: '#666' }}>{customerObj.company}</div>}
                </>
              ) : (
                <div style={{ color: '#aaa', fontStyle: 'italic' }}>Select a customer...</div>
              )}
            </div>
          </div>

          <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse', marginBottom: 12 }}>
            <thead>
              <tr style={{ background: 'var(--primary)', color: 'white' }}>
                <th style={{ padding: '6px 8px', textAlign: 'left' }}>Description</th>
                <th style={{ padding: '6px 4px', textAlign: 'center' }}>Qty</th>
                <th style={{ padding: '6px 8px', textAlign: 'right' }}>Total</th>
              </tr>
            </thead>
            <tbody>
              {services.map((s, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? '#f9faff' : 'white' }}>
                  <td style={{ padding: '6px 8px' }}>{s.description || 'Untitled Service'}</td>
                  <td style={{ padding: '6px 4px', textAlign: 'center' }}>{s.hours}</td>
                  <td style={{ padding: '6px 8px', textAlign: 'right' }}>${(s.hours * s.rate).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{ fontSize: 12, borderTop: '1px solid var(--border)', paddingTop: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ color: '#666' }}>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ color: '#666' }}>Tax (10%)</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: 14, borderTop: '1px solid var(--border)', paddingTop: 8, marginTop: 4 }}>
              <span>TOTAL</span>
              <span style={{ color: 'var(--primary)' }}>${total.toFixed(2)}</span>
            </div>
          </div>

          {notes && (
            <div style={{ marginTop: 12, fontSize: 11, color: '#666', fontStyle: 'italic', borderTop: '1px solid var(--border)', paddingTop: 8 }}>
              Notes: {notes}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

export default withAuth(CreateInvoice);
