import { useEffect, useState } from 'react';
import Layout from '../../components/layout/Layout';
import withAuth from '../../components/ui/withAuth';
import api from '../../lib/api';
import Link from 'next/link';
import toast from 'react-hot-toast';

function Invoices() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState(null);

  useEffect(() => { fetchInvoices(); }, []);

  const fetchInvoices = async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/invoices');
      setInvoices(data);
    } catch {
      toast.error('Failed to load invoices');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    try {
      await api.delete(`/invoices/${deleteId}`);
      toast.success('Invoice deleted');
      setDeleteId(null);
      fetchInvoices();
    } catch {
      toast.error('Failed to delete invoice');
    }
  };

  const handleDownloadPDF = async (invoice) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_URL}/invoices/${invoice._id}/pdf`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (!response.ok) throw new Error('PDF generation failed');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${invoice.invoiceNumber}.pdf`;
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success('PDF downloaded!');
    } catch {
      toast.error('Failed to download PDF');
    }
  };

  const statusBadge = (status) => {
    const map = { Draft: 'badge-inactive', Sent: 'badge-lead', Paid: 'badge-active' };
    return <span className={`badge ${map[status] || ''}`}>{status}</span>;
  };

  return (
    <Layout>
      <div className="page-header">
        <div className="page-title">
          <h1>Invoice Generation</h1>
          <p>Create and manage your business invoices.</p>
        </div>
        <Link href="/invoices/create">
          <button className="btn-primary">🧾 Create Invoice</button>
        </Link>
      </div>

      <div className="card">
        {loading ? (
          <div className="loading">Loading invoices...</div>
        ) : invoices.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#666' }}>
            <p style={{ fontSize: 16, marginBottom: 8 }}>No invoices yet.</p>
            <Link href="/invoices/create">
              <button className="btn-primary btn-sm">Create Your First Invoice</button>
            </Link>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Invoice #</th>
                  <th>Customer</th>
                  <th>Company</th>
                  <th>Services</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((inv) => (
                  <tr key={inv._id}>
                    <td style={{ fontWeight: 600, color: 'var(--primary)' }}>{inv.invoiceNumber}</td>
                    <td>{inv.customer?.name || '—'}</td>
                    <td>{inv.customer?.company || '—'}</td>
                    <td>{inv.services?.length} item(s)</td>
                    <td style={{ fontWeight: 600 }}>${inv.total?.toFixed(2)}</td>
                    <td>{statusBadge(inv.status)}</td>
                    <td>{new Date(inv.createdAt).toLocaleDateString()}</td>
                    <td>
                      <div className="action-btns">
                        <button
                          className="btn-primary btn-sm"
                          onClick={() => handleDownloadPDF(inv)}
                          title="Download PDF"
                        >
                          ⬇ PDF
                        </button>
                        <button
                          className="btn-danger btn-sm"
                          onClick={() => setDeleteId(inv._id)}
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {deleteId && (
        <div className="modal-overlay" onClick={() => setDeleteId(null)}>
          <div className="modal" style={{ maxWidth: 400 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Delete Invoice</h3>
              <button className="modal-close" onClick={() => setDeleteId(null)}>✕</button>
            </div>
            <p style={{ color: '#666', marginBottom: 24 }}>Are you sure you want to delete this invoice?</p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button className="btn-secondary" onClick={() => setDeleteId(null)}>Cancel</button>
              <button className="btn-danger" onClick={handleDelete}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}

export default withAuth(Invoices);
