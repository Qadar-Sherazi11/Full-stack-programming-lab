import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Layout from '../../../components/layout/Layout';
import withAuth from '../../../components/ui/withAuth';
import CustomerForm from '../../../components/ui/CustomerForm';
import api from '../../../lib/api';
import toast from 'react-hot-toast';
import Link from 'next/link';

function EditCustomer() {
  const router = useRouter();
  const { id } = router.query;
  const [customer, setCustomer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  useEffect(() => {
    if (!id) return;
    api.get(`/customers/${id}`)
      .then(({ data }) => setCustomer(data))
      .catch(() => { toast.error('Customer not found'); router.push('/customers'); })
      .finally(() => setFetching(false));
  }, [id]);

  const handleSubmit = async (form) => {
    setLoading(true);
    try {
      await api.put(`/customers/${id}`, form);
      toast.success('Customer updated successfully!');
      router.push('/customers');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update customer');
    } finally {
      setLoading(false);
    }
  };

  if (fetching) return <Layout><div className="loading">Loading customer...</div></Layout>;
  if (!customer) return null;

  return (
    <Layout>
      <div className="page-header">
        <div className="page-title">
          <div style={{ fontSize: 13, color: '#666', marginBottom: 4 }}>
            <Link href="/customers">Customers</Link> › Edit
          </div>
          <h1>Edit Customer</h1>
          <p>Updating: {customer.name}</p>
        </div>
      </div>

      <div className="card" style={{ maxWidth: 720 }}>
        <CustomerForm
          initial={customer}
          onSubmit={handleSubmit}
          loading={loading}
          submitLabel="Update Customer"
        />
      </div>
    </Layout>
  );
}

export default withAuth(EditCustomer);
