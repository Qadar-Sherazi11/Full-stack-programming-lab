import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function Register() {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [agreed, setAgreed] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (!form.name || !form.email || !form.password || !form.confirmPassword) {
      setError('Please fill in all fields');
      return;
    }
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    if (!agreed) {
      setError('Please agree to the Terms of Service');
      return;
    }

    setLoading(true);
    try {
      await register(form.name, form.email, form.password);
      toast.success('Account created successfully!');
    } catch (err) {
      const msg = err.response?.data?.message || 'Registration failed. Please try again.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <div className="auth-left">
          <div style={{ fontSize: 32, marginBottom: 12 }}>✦</div>
          <h1>Nexus CRM</h1>
          <p style={{ marginTop: 8, lineHeight: 1.6 }}>Enterprise-grade customer intelligence for high-velocity teams.</p>
          <div style={{ marginTop: 28 }}>
            <div style={{ padding: '14px', background: 'rgba(255,255,255,0.1)', borderRadius: 8, marginBottom: 12 }}>
              <div style={{ fontWeight: 600, fontSize: 13 }}>📈 Advanced Analytics</div>
              <div style={{ fontSize: 12, marginTop: 4, opacity: 0.8 }}>Real-time data visualization to drive your revenue growth.</div>
            </div>
            <div style={{ padding: '14px', background: 'rgba(255,255,255,0.1)', borderRadius: 8 }}>
              <div style={{ fontWeight: 600, fontSize: 13 }}>🔒 Enterprise Security</div>
              <div style={{ fontSize: 12, marginTop: 4, opacity: 0.8 }}>JWT-based auth with encrypted password storage.</div>
            </div>
          </div>
        </div>

        <div className="auth-right">
          <h2>Create your workspace</h2>
          <p className="subtitle">Join thousands of enterprises optimizing their workflows today.</p>

          {error && <div className="error-msg">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Full Name</label>
              <input
                type="text"
                name="name"
                placeholder="Enter your full name"
                value={form.name}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label>Work Email</label>
              <input
                type="email"
                name="email"
                placeholder="name@company.com"
                value={form.email}
                onChange={handleChange}
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label>Password</label>
                <input
                  type="password"
                  name="password"
                  placeholder="Min. 6 characters"
                  value={form.password}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label>Confirm Password</label>
                <input
                  type="password"
                  name="confirmPassword"
                  placeholder="Re-enter password"
                  value={form.confirmPassword}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <input
                type="checkbox"
                id="agree"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                style={{ width: 'auto' }}
              />
              <label htmlFor="agree" style={{ fontWeight: 'normal', marginBottom: 0, fontSize: 13, color: '#666' }}>
                I agree to the <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Terms of Service</span> and <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Privacy Policy</span>
              </label>
            </div>

            <button
              type="submit"
              className="btn-primary"
              style={{ width: '100%', padding: '12px', fontSize: 15 }}
              disabled={loading}
            >
              {loading ? 'Creating account...' : 'CREATE ACCOUNT'}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 24, fontSize: 14, color: '#666' }}>
            Already have an account?{' '}
            <Link href="/auth/login" style={{ color: 'var(--primary)', fontWeight: 600 }}>
              Sign In
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
