import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const { login } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPw, setShowPw] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.email || !form.password) {
      setError('Please fill in all fields');
      return;
    }
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Welcome back!');
    } catch (err) {
      const msg = err.response?.data?.message || 'Login failed. Please try again.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-box">
        <div className="auth-left">
          <div style={{ fontSize: 32, marginBottom: 12 }}>✦</div>
          <h1>Nexus CRM</h1>
          <p style={{ marginTop: 8, lineHeight: 1.6 }}>Simple. Powerful. Connected.<br />Manage all your customer relationships in one place.</p>
          <div style={{ marginTop: 32, padding: '16px', background: 'rgba(255,255,255,0.1)', borderRadius: 8 }}>
            <div style={{ fontWeight: 600, fontSize: 13 }}>🔐 Demo Credentials</div>
            <div style={{ marginTop: 6, fontSize: 13, opacity: 0.85 }}>
              Email: admin@nexuscrm.com<br />Password: admin123
            </div>
          </div>
        </div>

        <div className="auth-right">
          <h2>Welcome back</h2>
          <p className="subtitle">Sign in to manage your enterprise workflows.</p>

          {error && <div className="error-msg">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                name="email"
                placeholder="name@company.com"
                value={form.email}
                onChange={handleChange}
                autoComplete="email"
              />
            </div>

            <div className="form-group">
              <label>Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  type={showPw ? 'text' : 'password'}
                  name="password"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={handleChange}
                  autoComplete="current-password"
                  style={{ paddingRight: 40 }}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', background: 'none', color: '#666', padding: 0 }}
                >
                  {showPw ? '🙈' : '👁️'}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="btn-primary"
              style={{ width: '100%', padding: '12px', fontSize: 15, marginTop: 8 }}
              disabled={loading}
            >
              {loading ? 'Signing in...' : 'Sign In →'}
            </button>
          </form>

          <div style={{ textAlign: 'center', marginTop: 24, fontSize: 14, color: '#666' }}>
            New to Nexus CRM?{' '}
            <Link href="/auth/register" style={{ color: 'var(--primary)', fontWeight: 600 }}>
              Create Account
            </Link>
          </div>

          <div style={{ textAlign: 'center', marginTop: 32, fontSize: 12, color: '#aaa' }}>
            © 2024 Nexus CRM Enterprise Edition
          </div>
        </div>
      </div>
    </div>
  );
}
