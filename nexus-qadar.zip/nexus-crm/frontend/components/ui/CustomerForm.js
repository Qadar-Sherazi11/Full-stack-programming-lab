import { useState } from 'react';

const INITIAL = {
  name: '', email: '', phone: '', company: '', status: 'Lead', address: '', notes: '',
};

export default function CustomerForm({ initial = INITIAL, onSubmit, loading, submitLabel = 'Save Customer' }) {
  const [form, setForm] = useState({ ...INITIAL, ...initial });
  const [error, setError] = useState('');

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    if (!form.name.trim()) return setError('Name is required');
    if (!form.email.trim()) return setError('Email is required');
    if (!form.phone.trim()) return setError('Phone is required');
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return setError('Please enter a valid email');
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit}>
      {error && <div className="error-msg">{error}</div>}

      <div className="form-row">
        <div className="form-group">
          <label>Full Name *</label>
          <input name="name" value={form.name} onChange={handleChange} placeholder="John Smith" />
        </div>
        <div className="form-group">
          <label>Email Address *</label>
          <input name="email" type="email" value={form.email} onChange={handleChange} placeholder="john@company.com" />
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label>Phone Number *</label>
          <input name="phone" value={form.phone} onChange={handleChange} placeholder="+1-555-0100" />
        </div>
        <div className="form-group">
          <label>Company</label>
          <input name="company" value={form.company} onChange={handleChange} placeholder="Acme Corp" />
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label>Status</label>
          <select name="status" value={form.status} onChange={handleChange}>
            <option value="Lead">Lead</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
        <div className="form-group">
          <label>Address</label>
          <input name="address" value={form.address} onChange={handleChange} placeholder="123 Main St, City, State" />
        </div>
      </div>

      <div className="form-group">
        <label>Notes</label>
        <textarea
          name="notes"
          value={form.notes}
          onChange={handleChange}
          placeholder="Additional notes about this customer..."
          rows={3}
          style={{ resize: 'vertical' }}
        />
      </div>

      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 8 }}>
        <button type="button" className="btn-secondary" onClick={() => window.history.back()}>
          Cancel
        </button>
        <button type="submit" className="btn-primary" disabled={loading}>
          {loading ? 'Saving...' : submitLabel}
        </button>
      </div>
    </form>
  );
}
