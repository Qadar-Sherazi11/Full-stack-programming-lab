import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/router';
import api from '../../lib/api';

const RESPONSES = {
  hello: 'Hello! I am your Nexus Assistant. How can I help you today?\n\nTry: "show customers", "add customer", "create invoice", "dashboard", or "help".',
  help: 'Available commands:\n• "show customers" - View customer list\n• "add customer" - Go to add customer form\n• "create invoice" - Open invoice page\n• "dashboard" - Go to dashboard\n• "show invoices" - View invoices\n• "customer count" - Total customers',
  unknown: 'Sorry, I did not understand that. Type "help" to see available commands.',
};

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([{ type: 'bot', text: 'Hello! I am your Nexus Assistant. Type "help" for commands.' }]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);
  const router = useRouter();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const addMsg = (type, text) => setMessages(prev => [...prev, { type, text }]);

  const handleCommand = async (cmd) => {
    const lower = cmd.toLowerCase().trim();

    if (lower === 'hello' || lower === 'hi' || lower === 'hey') {
      addMsg('bot', RESPONSES.hello);
    } else if (lower === 'help') {
      addMsg('bot', RESPONSES.help);
    } else if (lower.includes('show customer') || lower === 'customers') {
      addMsg('bot', 'Taking you to the Customer Directory...');
      setTimeout(() => router.push('/customers'), 800);
    } else if (lower.includes('add customer') || lower.includes('new customer')) {
      addMsg('bot', 'Opening the Add Customer form...');
      setTimeout(() => router.push('/customers/add'), 800);
    } else if (lower.includes('invoice') || lower.includes('create invoice')) {
      addMsg('bot', 'Opening the Invoice module...');
      setTimeout(() => router.push('/invoices'), 800);
    } else if (lower === 'dashboard' || lower.includes('go to dashboard')) {
      addMsg('bot', 'Taking you to the Dashboard...');
      setTimeout(() => router.push('/dashboard'), 800);
    } else if (lower.includes('customer count') || lower.includes('how many customers')) {
      try {
        const { data } = await api.get('/dashboard/stats');
        addMsg('bot', `You have ${data.totalCustomers} total customers.\n• Active: ${data.activeCustomers}\n• Leads: ${data.leads}`);
      } catch {
        addMsg('bot', 'Could not fetch customer data. Please try again.');
      }
    } else if (lower.includes('show invoice') || lower.includes('list invoice')) {
      addMsg('bot', 'Taking you to the Invoices page...');
      setTimeout(() => router.push('/invoices'), 800);
    } else {
      addMsg('bot', RESPONSES.unknown);
    }
  };

  const handleSend = () => {
    if (!input.trim()) return;
    addMsg('user', input);
    handleCommand(input);
    setInput('');
  };

  const handleKey = (e) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <>
      <button className="chatbot-btn" onClick={() => setOpen(!open)} title="Nexus Assistant">
        💬
      </button>

      {open && (
        <div className="chatbot-window">
          <div className="chatbot-header">
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Nexus Assistant</div>
              <div style={{ fontSize: 11, opacity: 0.8 }}>Rule-based CRM Helper</div>
            </div>
            <button onClick={() => setOpen(false)} style={{ background: 'none', color: 'white', fontSize: 18, padding: '0 4px' }}>✕</button>
          </div>

          <div className="chatbot-messages">
            {messages.map((msg, i) => (
              <div key={i} className={`chat-msg ${msg.type}`} style={{ whiteSpace: 'pre-line' }}>
                {msg.text}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="chatbot-input">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Type a command..."
            />
            <button onClick={handleSend}>Send</button>
          </div>
        </div>
      )}
    </>
  );
}
